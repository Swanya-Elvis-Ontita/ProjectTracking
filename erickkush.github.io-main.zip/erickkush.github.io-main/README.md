# A Guided Project Tracking System of 5 collaborators 

## Goal: Building a distributed information system with heterogeneous clients

## Project Structure (7-Phases)

### 1.Introduction to Distributed System & Database creation [DONE]
### 2. Building a business component using C# [DONE]
### 3. Building an admin GUI using C#
### 4. Introduction to .NET remoting (implement a remote server application))
### 5. Create a web service and client website
### 6. Develop a java client
### 7. Use creativity to improve on the solution we build
